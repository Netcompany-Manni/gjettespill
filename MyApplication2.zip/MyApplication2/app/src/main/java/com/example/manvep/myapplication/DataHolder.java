package com.example.manvep.myapplication;

public class DataHolder {

   String chosenShortName;
   String correctShortName;
   String correctProfilePictureURL;

    public String getCorrectProfilePicture() {
        return correctProfilePictureURL;
    }

    public void setCorrectProfilePicture(String correctProfilePicture) {
        this.correctProfilePictureURL = correctProfilePicture;
    }

    public String getChosenShortName() {
        return chosenShortName;
    }

    public void setChosenShortName(String chosenShortName) {
        this.chosenShortName = chosenShortName;
    }

    public String getCorrectShortName() {
        return correctShortName;
    }

    public void setCorrectShortName(String correctShortName) {
        this.correctShortName = correctShortName;
    }
}
