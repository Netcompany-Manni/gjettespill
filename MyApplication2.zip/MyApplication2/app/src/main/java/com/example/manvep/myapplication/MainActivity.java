package com.example.manvep.myapplication;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.squareup.picasso.Picasso;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class MainActivity extends AppCompatActivity {
List<Ansatt> globalListeMedAnsatte;
TextView output;
Button knapp1, knapp2, knapp3;
DataHolder data = new DataHolder();
static int antallRiktige, antallFeil = 0;
int index = 0;
int randomIndex1, randomIndex2, randomIndex3 = 0;
Random random = new Random();
List<Button> listeMedKnapper = new ArrayList<>();

ImageView outputImage;
private Ansatt currentAnsatt;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        knapp1 = findViewById(R.id.knapp1);
        knapp2 = findViewById(R.id.knapp2);
        knapp3 = findViewById(R.id.knapp3);
        listeMedKnapper.add(knapp1);
        listeMedKnapper.add(knapp2);
        listeMedKnapper.add(knapp3);

        output = findViewById(R.id.OutputField);
        outputImage = findViewById(R.id.imageView2);
        loadAllData();


        knapp1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                data.chosenShortName = knapp1.getText().toString();
                validateData(data.chosenShortName,data.correctShortName);
            }
        });
        knapp2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                data.chosenShortName = knapp2.getText().toString();
                validateData(data.chosenShortName,data.correctShortName);

            }
        });

        knapp3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                data.chosenShortName = knapp3.getText().toString();
                validateData(data.chosenShortName,data.correctShortName);
            }
        });

    }

    void validateData(String chosen, String correct){
        if(chosen.equals(correct)){
            antallRiktige++;
        }
        else
        {
            antallFeil++;
        }
        lastInnNyDataIAlleFiler();
        output.setText("Korrekte: "+antallRiktige+" : - : Feil: "+antallFeil);

    }

    private void lastInnNyDataIAlleFiler() {

        int randomRiktigTall = random.nextInt(3);
        for(int i = 0; i<3; i++){
            if(i == randomRiktigTall){
                Ansatt tempAnsatt = globalListeMedAnsatte.get(random.nextInt(globalListeMedAnsatte.size()));
                listeMedKnapper.get(i).setText(tempAnsatt.getShortName());
                data.correctShortName = tempAnsatt.getShortName();
                Picasso.get().load(tempAnsatt.getProfileImageUrl()).into(outputImage);
            }
            else
            {
                String tempName = globalListeMedAnsatte.get(random.nextInt(globalListeMedAnsatte.size())).getShortName();
                listeMedKnapper.get(i).setText(tempName);
            }
        }

    }


    void loadAllData(){
         Retrofit.Builder builder =  new Retrofit.Builder().baseUrl("https://faghelg.herokuapp.com")
                 .addConverterFactory(GsonConverterFactory.create());

         Retrofit retrofit = builder.build();
         AnsattClient ansattklient = retrofit.create(AnsattClient.class);
         ansattklient.listeMedAnsatte();
         Call<List<Ansatt>> call = ansattklient.listeMedAnsatte();

         call.enqueue(new Callback<List<Ansatt>>() {
             @Override
             public void onResponse(Call<List<Ansatt>> call, Response<List<Ansatt>> response) {
                 List<Ansatt> ansattData = response.body();
                 globalListeMedAnsatte = ansattData;
                lastInnNyDataIAlleFiler();
             }

             @Override
             public void onFailure(Call<List<Ansatt>> call, Throwable t) {
                 Toast.makeText(MainActivity.this,"Error",Toast.LENGTH_SHORT).show();
             }
         });
     }

}
