package com.example.manvep.myapplication;

import java.util.List;

import retrofit2.Call;
import retrofit2.http.GET;

public interface AnsattClient {

    @GET("/persons")
    Call<List<Ansatt>> listeMedAnsatte();

}
